## 🎯 Objetivos
   - [ ] 1.Usuário adicionar cidade.
   - [ ] 2.Usuário adicionar valores na matriz adjacentes.
   - [ ] 3.Salvar matriz adjacentes.
   - [ ] 4.Exibir as matrizes (distância ou predecessores).
   - [ ] 5.Executar o algoritimo?
   - [ ] 6.Salvar os resultados em arquivo .txt (distância e predecessores).
   - [ ] 7.Mostrar menor caminho entre dois municípios, após execução do algoritimo

## 📁 Estrutura do Repositório
  `main.c`: arquivo principal para executar o programa, irá ter todas as funções.
  
  `entrada.c`: irá ler o arquivo e amazenar a quantidade de cidades, nomes de cidades e a matriz de adjacencias.
  
  `interfaces.c`: tela de exibição para o usuário.
