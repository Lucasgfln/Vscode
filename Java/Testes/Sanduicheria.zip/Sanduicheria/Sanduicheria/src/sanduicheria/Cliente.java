
package sanduicheria;


public class Cliente {
	private String nome;
	private String cpf;
	private String email;
	private String telefone;
	private String endereco;

	// -- Getters e Setters --

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getEndereço() {
        return endereco;
    }

    public void setEndereço(String endereço) {
        this.endereco = endereço;
    }

    public void show() {
        System.out.println(" ===== CLIENTE =====");
		System.out.println("Nome: " + nome);
		System.out.println("CPF: " + cpf);
		System.out.println("Email: " + email);
		System.out.println("Telefone: " + telefone);
		System.out.println("Endereço: " + endereco);
	}

}

	
