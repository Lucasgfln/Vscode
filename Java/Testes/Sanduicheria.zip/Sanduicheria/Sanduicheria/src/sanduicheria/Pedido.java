package sanduicheria;

  public class Pedido {
    private int idPedido;
    private String status;
    private String nome_Cliente;
    private float valorFinal;
    private String forma_Pagamento;
    private String observacao;
    private String entrega;
    private String endereco;
    
   /* public Pedido(int idPedido, int status, int idCliente, int idItem, float valorFinal, int foramPagamento, String observacao, int entrega, String endereco) {
        this.idPedido = idPedido;
        this.status = status;
        this.idCliente = idCliente;
        this.idItem = idItem;
        this.valorFinal = valorFinal;
        this.foramPagamento = foramPagamento;
        this.observacao = observacao;
        this.entrega = entrega;
        this.endereco = endereco;
    } */

    public int getIdPedido() {
        return idPedido;
    }

    public void setIdPedido(int idPedido) {
        this.idPedido = idPedido;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getNome_Cliente() {
        return nome_Cliente;
    }

    public void setNome_Cliente(String nome_Cliente) {
        this.nome_Cliente = nome_Cliente;
    }

    public float getValorFinal() {
        return valorFinal;
    }

    public void setValorFinal(float valorFinal) {
        this.valorFinal = valorFinal;
    }

    public String getForma_Pagamento() {
        return forma_Pagamento;
    }

    public void setForma_Pagamento(String forma_Pagamento) {
        this.forma_Pagamento = forma_Pagamento;
    }

    public String getObservacao() {
        return observacao;
    }

    public void setObservacao(String observacao) {
        this.observacao = observacao;
    }

    public String getEntrega() {
        return entrega;
    }

    public void setEntrega(String entrega) {
        this.entrega = entrega;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }
    
   
  
    public void show() {
        System.out.println(" ==== PEDIDO ====");
        System.out.println("ID do Pedido: " + idPedido);
        System.out.println("Status: " + status);
        System.out.println("ID do Cliente: " + nome_Cliente);
        System.out.println("Valor Final: " + valorFinal);
        System.out.println("Forma de Pagamento: " + forma_Pagamento);
        System.out.println("Observação: " + observacao);
        System.out.println("Entrega: " + entrega);
        System.out.println("Endereço: " + endereco);
    }

    public void delete() {
        idPedido = 0;
        status = null;
        nome_Cliente = null;
        valorFinal = 0;
        forma_Pagamento = null;
        observacao = null;
        entrega = null;
        endereco = null;
    }

  }
