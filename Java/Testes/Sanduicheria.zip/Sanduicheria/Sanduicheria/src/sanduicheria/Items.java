
package sanduicheria;

public class Items {

    private String tipo_bebida;
    private double preco;
    private int quantidade;
    private String categoria;
    private int id;

    public Items(String n, double preco, int Qtn, String categ, int ID) {
        this.tipo_bebida = n;
        this.preco = preco;
        this.quantidade = Qtn;
        this.categoria = categ;
        this.id = ID;
    }

    public String getNome() {
        return tipo_bebida;
    }

    public double getPreco() {
        return preco;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public String getCategoria() {
        return categoria;
    }

    public int getId() {
        return id;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }

    public void show() {
        System.out.println("Código: " + id);
        System.out.println("Valor: " + preco);
        System.out.println("Descrição: " + tipo_bebida);
        System.out.println("Categoria: " + categoria);
    }
}