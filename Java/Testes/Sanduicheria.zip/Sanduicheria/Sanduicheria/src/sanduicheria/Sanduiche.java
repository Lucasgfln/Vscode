
package sanduicheria;

public class Sanduiche {
    private String nome;
    private String tipo_Pao;
    private String tipo_Carne;
    private String tipo_Recheio;
    private String queijo;
    private boolean verduras;
    private boolean molhos; 

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getTipo_Pao() {
        return tipo_Pao;
    }

    public void setTipo_Pao(String tipo_Pao) {
        this.tipo_Pao = tipo_Pao;
    }

    public String getTipo_Carne() {
        return tipo_Carne;
    }

    public void setTipo_Carne(String tipo_Carne) {
        this.tipo_Carne = tipo_Carne;
    }

    public String getTipo_Recheio() {
        return tipo_Recheio;
    }

    public void setTipo_Recheio(String tipo_Recheio) {
        this.tipo_Recheio = tipo_Recheio;
    }

    public String getQueijo() {
        return queijo;
    }

    public void setQueijo(String queijo) {
        this.queijo = queijo;
    }

    public boolean isVerduras() {
        return verduras;
    }

    public void setVerduras(boolean verduras) {
        this.verduras = verduras;
    }

    public boolean isMolhos() {
        return molhos;
    }

    public void setMolhos(boolean molhos) {
        this.molhos = molhos;
    }
    
    public void show() {
    System.out.println("=== SANDÚICHE ===");
    System.out.println("Nome: " + nome);
    System.out.println("Pão: " + tipo_Pao);
    System.out.println("Carne: " + tipo_Carne);
    System.out.println("Recheio: " + tipo_Recheio);
    System.out.println("Queijo: " + queijo);
    System.out.println("Verduras: " + (verduras ? "Sim" : "Não"));
    System.out.println("Molhos: " + (molhos ? "Sim" : "Não"));
}
    public void delete() {
    this.nome = null;
    this.tipo_Pao = null;
    this.tipo_Carne = null;
    this.tipo_Recheio = null;
    this.queijo = null;
    this.verduras = false;
    this.molhos = false;
    
    System.out.println("Sanduíche deletado!");
}

}
