
package sanduicheria;

public class Sanduicheria {

    public static void main(String[] args) {
      
        /*criar um cliente*/
        
        Cliente client = new Cliente();
        
        client.setNome("Marcelo");
        client.setCpf("400.028.922-00");
        client.setEmail("marceloteste@gmail.com");
        client.setTelefone("4002-8922");
        client.setEndereço("Avenida Boa Viagem");
        
        /*criar um pedido*/
        
        Pedido p1 = new Pedido();
        
        p1.setIdPedido(492);
        p1.setStatus("Em Preparo");
        p1.setNome_Cliente("Marcelo");
        p1.setValorFinal(49.67f);
        p1.setForma_Pagamento("Crédito");
        p1.setObservacao("Sem");
        p1.setEntrega("Aguardando Preparo");
        p1.setEndereco("Avenida Boa Viagem");
        
        /*criar um funcionario*/
        
        Funcionario atendente = new Funcionario();
        
        atendente.setNome("Jamilly");
        atendente.setCpf("458.789.123-00");
        atendente.setEmail("Jamillyteste@icloud.com");
        atendente.setIdade(23);
        atendente.setEndereço("Rua dos Afogados");
        atendente.setAtivo(true);
        atendente.setCargo("Atendente");
        atendente.setSalario(1394d);
        
        /*criar Sanduiche*/
        
        Sanduiche burguer = new Sanduiche();
        
        burguer.setNome("Mega X-Tudo");
        burguer.setTipo_Pao("Pão de Hambúrguer");
        burguer.setTipo_Carne("Artesanal");
        burguer.setTipo_Recheio("Bacon e Ovo");
        burguer.setQueijo("Muçarela");
        burguer.setVerduras(true);
        burguer.setMolhos(true);
        
        /*criar Adicionais*/

        Adicionais cocaCola1L = new Adicionais("Coca-Cola1L", 7, 1, "Refrigerantes", 548);

        
        atendente.show();
        System.out.println();
        client.show();
        System.out.println();
        p1.show();
        System.out.println();
        burguer.show();
        System.out.println();
        cocaCola1L.show();

    }   
}
