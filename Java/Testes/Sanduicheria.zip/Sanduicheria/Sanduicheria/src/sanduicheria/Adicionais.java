/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sanduicheria;

/**
 *
 * @author Lael
 */
public class Adicionais {
  
    private String descricao;
    private double preco;
    private int quantidade;
    private String categoria;
    private int id;

    public Adicionais(String dscrc, double preco, int qtd, String ctgr, int id) {
        this.descricao = descricao;
        this.preco = preco;
        this.quantidade = qtd;
        this.categoria = ctgr;
        this.id = id;
    }

    public String getDescricao() {
        return descricao;
    }

    public double getPreco() {
        return preco;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public String getCategoria() {
        return categoria;
    }

    public int getId() {
        return id;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }

    public void show() {
        System.out.println(" ======== ADICIONAIS ========");
        System.out.println("Código: " + id);
        System.out.println("Valor: " + preco);
        System.out.println("Descrição: " + descricao);
        System.out.println("Categoria: " + categoria);
    }
}

